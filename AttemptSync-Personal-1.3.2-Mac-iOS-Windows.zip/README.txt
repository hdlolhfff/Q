Attempt Sync Personal 1.3.2 — Mac, iOS and Windows

Choose your platform folder and follow its INSTALL.txt.
Each folder includes the same tested universal Geode package, with
native binaries for Windows x64, Mac Intel/Apple Silicon, and iOS arm64.

Your upload key is included. Keep this ZIP private: anyone with it
can use your key to upload to your repository.
The token-free public release is available for viewers on GitHub.

One Sync All confirmation covers the batch. Live progress appears
in the bottom banner during comparing and uploading.
